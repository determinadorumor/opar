Gambito de viernes

Estos días participé de la lectura que promocioné días atrás. Estuvo bien. Apolínea. Así las lecturas de estos tiempos de mi vida. Los tiempos de la madurez. Los de la acedrada necesidad, del popio deseo. Los tiempos del cachivache y la fisura. 
La lectura fue en la librería ya famosa <em>Gambito de Alfil</em>, de Miguel Villafañe, el editor de Viñas. Frente a esa puerta deslucida de la Faculta de Filosofía  y Letras de calle Puan.Todo esa milicia humanista formada por el estado en el cuartel del barrio de Caballito debe tener una opinión de esa librería. </p>

<p>No yo porque no estudié en Puán: sino en la UNS y el en Consudec. <<Plug>PeepOpen>

<p>Cambios. <em>Gambito</em>... ya no está en un altos. Ya no se accede a partir de una escalera. Ahora desde la misma vereda donde se accede a la Facultad puede verse la vidriera, los títulos y la vida en la librería. </p>>

<p>Ese día viernes de la lactura y preámbulo para un feriado interminable pedalié desde mi trabajo de vuelta a Flores. Tráfico monumental, burócrata, imposible. Dorrego, Humbold, Honorio, Aranguren, todas calles atestadas de autos, transportando paciencia y despidiéndose de actividades de una semana grave. </p>>

<p>Cuando había dejado los petates de mi trabajo de oficina en mi casa, partí sí para la lectura. Como estaba ansioso compré una Pepsi Baby para ir bajando el vértigo de mi cabeza. Me interné por esas manzanas que poco frecuento hasta que por la ventana vi el set de lectura y a mi amigo Piro. <<Plug>PeepOpen>

<p>Detrás del puesto central de la libraría y en el medio del local había 1 micrófono y una guitarra enchufadas a 2 amplis apoyadas en una frazada a cuadro. Cuando me mostró la escenografía me hizo un racional: abran las lecturas. La frase de la semana. El tópico de la semana. De a poco fueron llegando todos los poetas invitados. Jacqui Berend, Pablo Katcha y Santiago Pintabona, <em>el autor de la sedante del pacto</em> que me regalaron un libro y hablamos de los
pequeños, Lau Crespi que trajo también unas traducciones y leyó unos poemas
buenísimos. Aldo Giacometi, el agitador grafomaníaco víctima de de la inquietud, y también la poeta en la tierra de los papers, Mara Pedrazzoli. Leímos, nos escuchamos, nos divertimos y fuimos extinguendo un whisky Sir Edwards, mi petaca con un modesto y picante Vat 69 y otras cervezas que iba a comprar Giacometi. Tanto alcohol terminó curando al poeta que vino maltrecho tomando té de aperitivo y liberó de su peso al que temía que las palabras se nieguen a ubicarse en la
zona
fértil del pensamiento.</p>

<p>Después de charlar y brindar on amigos que se acercaron fuimos a una pizería que recomendó Miguel. Comimos y seguimos con la cerveza hasta que la noche le entregó un destino a cada uno de los comensales. El mío fue el de una caminata solitaria hasta mi departamento. Llegué cansado y ablandado por la caña. Llegué fundido y me acosté con zapatilas y campera para no prender la onerosa caldera. </p> 

Tags: lecturas,
