La yerba de mi ánimo hoy no devuelve espuma

Quizá los chinos en su bebida diaria no tienen esa experiencia trágica del tiempo. Dicen que ese té floral llamado olong, creo que en cristiano se dice "ulong", guarda el mejor gusto en la última de las 5 infusiones en las que sus hebras enturbian el agua. Imagino que mientras hunden la nariz en la taza los compañeros orientales sabrán que ese dulce té que los calma será mejor la próxima. Los criollos, en cambio, vivimos las sesiones de mate como un viaje recto a la extinción. El primer
mate, con su plenitud irá apagándose como el fuego de una pira. 

Verde en esta tarde enumero estos achaques con este corazón acostumbrado a investigar mi rostro en la superficie intervenida por los palos amarillos de un mate lavado. Mi dentadura va a la disolución. Infecciones, caries, piezas que en un momento se desconectaron de mi sistema nervioso por un tratamiento de conducto hoy, con un color ajeno a mí empiezan a astillarse y sacar turno para ir a vivir la aventura de la basura.

También mi ojo derecho está resentido por la hipermetropía. Cuando salimos a cenar con N. quito mis antejos redondos, que ya empecé a odiar, y los uso como lupa. Acomo la distancia entre el papel y mis ojos y así empiezo a descifrar el nombre del plato y los ingredientes. Ella me recomienda ir urgente al oftalmólogo para graduar nuevamente los cristales, pero para mí es una pelea menor. No respondo y en mi cabeza me escucho repitiendo esos versos del viejo Gianuzzi, "el ojo y su
camino a la oscuridad".

Los veo la próxima, espero que con buenas noticias.


Tags: mate, te, gianuzzi, naturaleza
