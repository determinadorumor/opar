Viruta de alpargatas bajo el invierno metropolitano

<p>Sé que muchos de ustedes amigos no me conocen. Voy a presentar 
entonces una de mis actividades favoritas. Caminar largos kilómetros en 
esta ciudad. Excursiones qeu no se cuentan en cuadras sino en barrios, 
comunas, etc. Esta última gran caminata aproveché en principio un turno 
con el odontólogo y armé una ruta para aprovechar una larga marcha 
después de la jornada de oficina.</p><p>Constituyentes 4XXX. Ahí arrancó 
el turno con el dentista. En realidad no era solo un odontógo general 
sino una especialización extraña que en esa clínica escuché por primera 
vez. Estomatólogo. Especialista de las enfermedades de la boca. Después 
de la derivación de mi odontólogo a este especialista después que me 
econtrase un bulto en encía me preparé para un cáncer de boca. Lenta 
enfermedad, y propia de población con mis costumbres. Aquellso que 
prefieren las bebidas muy calientes, los fumadores de pipas y puros, así 
como los asiduos consumidores de alcohol, grupos en los que en la 
soledad participo. - Nada que ver - aclaró el especialista. Es una 
fístula, una infección que ha peforado varios tejidos y se expulsa 
lentamente desde esa turgencia. Un asco. Su solución es extraer la muela 
que corona esa deformidad bucal. Una menos. Una muela que dejará un 
defecto y recuerdo de su paso por mi boca.</p><p>Cerreti 27XX. Parroquia 
María Reina, Terminada la consulta, y aprovechando la hora, 18 45 libre 
en la zona cercana a Villa Urquiza fui hasta la misa que (Pater Fabián) 
[http://twitter.com/paterfabian] celebra casi diariamente a las 19. 
Siempre le prometo que voy a pasar y mis palabras me vuelven falluto. 
Ante la oportunidad caminé por la bicisenda, cruce esa amplia avenida 
que hoy olvidé su nombre. Separada por un hermoso boulevard y comercios 
raleados, apareciendo en la amplitud negra con su vidrieras simples. Qué 
hermosa luz da esta ciudad a cualquier noche. Hermosa. En ese clima 
espiritual atendimos el rato homilético de Fabián. Oh la sanación. 
Cuantos tipos y qué cerca está de nuestros corazones y cuán distante de 
esa máquina de pensar de nuestras cabezas. Luego de la bendición del fin 
de la misa siguó la adoración eucarísitca. Varias cosas me quedaban 
hacer en mi tarde. Seguí mi excursión con el corazón nuevo.</p><p>La 
estación Rosas me recibió con su espíritu comercial, naranjas rutilantes 
crecían como pirámides desde los cajones y los ciegos transeuntes 
ignoraban ese mundo maravilloso.</p><p>Recorrí Triunivirato esta noche 
color del plomo, su Kentucky en la esquina, sus confiterías ostentosas. 
<em>Las delicias</em>, <em>Un dulce permiso</em> y con la insistencia de 
los fantasmas aparecieron en mi cuerpo el gusto de los cuadrados de 
frola de membrillo, los eclairs de dulce de leche y chocolate. Tardes 
invertidas mi viejo departamento de involuntario esfuerzo, indescifrable 
resultado.</p><p>Las luces de la Iglesia levantada en honor al Apóstol 
Pablo agitaron mi corazón. A esa atención al bongó asincopado que sonaba 
en mi la cambié por un saludo al poeta laureado FC, Con un gorro y unos 
anteojos que parecían oscurecidos por humo me saludó y hablamos de un 
frío, que puntualmente él, percibía en la noche. Hablamos de Al Álvarez 
y esas prácticas de nado en pleno invierno. - 5 grados- Recordamos los 
carteles que indicaban la gélida temperatura del agua. El joven amor que 
sentía por su esposa. Una senectud vigorosa de la que imagino hoy 
inalcanzable, teniendo en cuenta que Álvarez había sido alpinista y 
suicida y yo, no sé FC, pero quien escribe apenas invirtió había unos 
pocos años en el atletismo y el resto lo entregó a las largase sesiones 
de alcohol, autocomplacencia y rutinario, incólume y tedioso trabajo 
ofimático. Seguí casi hasta Scalabrini cruzando la pesada altura de los 
edificios de policías de Concepción Arenal, la nueva Plaza Clemente con 
su verdor futuro cercado.</p><p>Chaval. Antes de Scalabrini la 
concurrida cervecería que regenteada por neuquinos era saqueada noche a 
noche por jóvenes fanas de la cerveza, como eramos con N, fanáticos de 
la cerveza. La juventud es un defecto que persiste en nosotros.</p><p>De 
ahí a Av Corrientes, y luego por Ángel Gallardo. Con el botón del puño 
de la campera sin abrochar. Colgando un Rosario de un plástico que 
cuando se expone a la luz devuelve una luz color verde, extraña, poco 
parecida a mi fe.</p><p>Corren algunos por el Parque Centenario.<br /> 
Agitando el corazón, yendo a ningún lado. Pensando en el día que se 
abran los caminos y podamos correr hasta quién sabe donde.</p><p>El Cid, 
esa escultura verde ante el cielo abierto sobre avenidas señoriales; 
Honorio, Gaona, Díaz Velez.</p><p>Ahí por la parsimoniosa Rojas que 
cuando se escapa de Gaona se vuelve un murmullo hermoso.</p><p>En Gainza 
y Aranguren saqué una bicicleta naranja fiscal y pedalié hasta Donato. 
Mi corazón al taco. Bajé y ya eran más de las 22. Mis muñecas se sentían 
como con frío.</p><p>En Flores ordené, preparé algo de comer, me di una 
ducha hirviendo hablé con N y por mi cabeza se sucedieron muchas cosas 
que son intransmisibles.</p>


Tags: caminatas, buenos aires,
