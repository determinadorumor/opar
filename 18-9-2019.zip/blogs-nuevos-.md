Blogs nuevos 

<p>No les llama la atención cuando entran a un blog, o a una página o algún sistema de escritra como más o menos íntimo. A diferencia de las formas de escribir más bulliciosas que parecen estar de moda. </p>

<p>En estos cambios de circulación de los textos y de auto lectura parecería que no hay más márgen y la autopercepción o eso que mucho escuché pero poco me documenté sobre la muerte del yo es la instancia ya discutida y aprobada como base coral de escritura. </p>

<p>No es que sea un gran conocedor de estos espacios, hoy parecen ser un nicho y no la manifestación más simple del presente como eran hace más de una década. </p>

<p>Se empieza a calentar el vidrio de la ventana y a la vez el tiempo de la tarde empiezan a cuenta los últimos minutos.</p>

<p>Quería contar esto para que no quede este post como una opinión de vejez. Seco, intelectual sin gracia, sin temperatura ni corazón. </p>

Tags: justificaciones-artesanales
